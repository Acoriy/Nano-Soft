import{j as t,m}from"./index-P0J-dgOx.js";function a({className:e,...s}){return t.jsx("div",{className:m("animate-pulse rounded-md bg-muted",e),...s})}export{a as S};
