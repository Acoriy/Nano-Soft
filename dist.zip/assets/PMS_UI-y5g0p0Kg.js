const s="/assets/PMS_UI-CRcND0_b.webp";export{s as D};
