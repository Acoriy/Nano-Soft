import{j as t,m}from"./index-ttiW1gZ0.js";function a({className:e,...s}){return t.jsx("div",{className:m("animate-pulse rounded-md bg-muted",e),...s})}export{a as S};
