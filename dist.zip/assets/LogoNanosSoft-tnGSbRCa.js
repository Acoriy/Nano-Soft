const o="/assets/LogoNanosSoft-BTHOrW4N.png";export{o as I};
